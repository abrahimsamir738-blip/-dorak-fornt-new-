
import React from 'react';
import { 
  Stethoscope, 
  Activity, 
  Baby, 
  Smile, 
  Eye, 
  Brain, 
  Bone, 
  UserRound,
  Heart,
  Thermometer
} from 'lucide-react';
import { Specialty, SpecialtyType, Doctor } from './types';

export const SPECIALTIES: Specialty[] = [
  { type: SpecialtyType.ORTHOPEDICS, icon: 'bone', color: 'text-blue-600' },
  { type: SpecialtyType.CARDIOLOGY, icon: 'heart', color: 'text-blue-600' },
  { type: SpecialtyType.PEDIATRICS, icon: 'baby', color: 'text-blue-600' },
  { type: SpecialtyType.DERMATOLOGY, icon: 'activity', color: 'text-blue-600' },
  { type: SpecialtyType.NEUROLOGY, icon: 'brain', color: 'text-blue-600' },
  { type: SpecialtyType.OPHTHALMOLOGY, icon: 'eye', color: 'text-blue-600' },
  { type: SpecialtyType.INTERNAL, icon: 'stethoscope', color: 'text-blue-600' },
  { type: SpecialtyType.SURGERY, icon: 'thermometer', color: 'text-blue-600' },
];

export const SPECIALTY_LABELS: Record<SpecialtyType, string> = {
  [SpecialtyType.ORTHOPEDICS]: 'عظام',
  [SpecialtyType.CARDIOLOGY]: 'قلب وأوعية',
  [SpecialtyType.PEDIATRICS]: 'أطفال',
  [SpecialtyType.DERMATOLOGY]: 'جلدية',
  [SpecialtyType.DENTAL]: 'أسنان',
  [SpecialtyType.OPHTHALMOLOGY]: 'رمد',
  [SpecialtyType.NEUROLOGY]: 'مخ وأعصاب',
  [SpecialtyType.INTERNAL]: 'باطنة',
  [SpecialtyType.SURGERY]: 'جراحة عامة',
  [SpecialtyType.GENERAL]: 'ممارس عام',
};

export const DOCTORS: Doctor[] = [
  {
    id: 'd1',
    name: 'د. أحمد إبراهيم',
    specialty: SpecialtyType.ORTHOPEDICS,
    title: 'استشاري جراحة العظام والكسور',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop',
    rating: 4.8,
    reviewsCount: 124,
    location: 'القاهرة، مصر',
    isOnline: true,
    consultationFee: 450,
    serviceFee: 15,
    currentQueueCount: 8, // مثال: 8 أشخاص منتظرين
    experience: '15 سنة',
    education: 'دكتوراه جراحة العظام، جامعة القاهرة',
    branches: [
      {
        id: 'b1',
        name: 'عيادة القاهرة الجديدة',
        address: 'قطعة 5، منطقة المستثمرين الشمالية، التجمع الخامس',
        mapUrl: 'https://www.google.com/maps/embed?pb=cairo',
        workingHours: 'السبت - الأربعاء: 4 م - 10 م',
        lat: 30.0131,
        lng: 31.4242
      },
      {
        id: 'b2',
        name: 'فرع الشيخ زايد',
        address: 'مركز بيفرلي هيلز الطبي، الشيخ زايد',
        mapUrl: 'https://www.google.com/maps/embed?pb=zayed',
        workingHours: 'يومياً: 10 ص - 6 م',
        lat: 30.0131,
        lng: 30.9858
      }
    ]
  },
  {
    id: 'd2',
    name: 'د. سارة أحمد',
    specialty: SpecialtyType.CARDIOLOGY,
    title: 'استشاري أمراض القلب والأوعية الدموية',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=400&h=400&fit=crop',
    rating: 4.9,
    reviewsCount: 89,
    location: 'الجيزة، مصر',
    isOnline: true,
    consultationFee: 450,
    serviceFee: 15,
    currentQueueCount: 3, // مثال: 3 أشخاص منتظرين
    experience: '12 سنة',
    education: 'دكتوراه القلب، جامعة عين شمس',
    branches: [
      {
        id: 'b3',
        name: 'فرع مصر الجديدة',
        address: '42 شارع النزهة، مصر الجديدة',
        mapUrl: 'https://www.google.com/maps/embed?pb=heliopolis',
        workingHours: 'يومياً: 10 ص - 6 م',
        lat: 30.0911,
        lng: 31.3239
      }
    ]
  }
];

export const getIcon = (name: string, size = 24) => {
  switch (name) {
    case 'bone': return <Bone size={size} />;
    case 'heart': return <Heart size={size} />;
    case 'activity': return <Activity size={size} />;
    case 'baby': return <Baby size={size} />;
    case 'smile': return <Smile size={size} />;
    case 'eye': return <Eye size={size} />;
    case 'brain': return <Brain size={size} />;
    case 'user': return <UserRound size={size} />;
    case 'stethoscope': return <Stethoscope size={size} />;
    case 'thermometer': return <Thermometer size={size} />;
    default: return <Stethoscope size={size} />;
  }
};
