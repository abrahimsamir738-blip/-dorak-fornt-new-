
import React, { useState, useEffect, createContext, useContext } from 'react';
import { Routes, Route, useLocation, useSearchParams, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { SpecialtyType, Doctor, Booking, Branch, Specialty } from './types';
import { DOCTORS, SPECIALTIES } from './constants';
import Layout from './components/Layout';
import Home from './Home';
import DoctorsPage from './pages/DoctorsPage';
import BookingPage from './pages/BookingPage';
import BookingModal from './components/BookingModal';
import AboutPage from './pages/AboutPage';
import ProfilePage from './pages/ProfilePage';

// Context Interface
interface DataContextType {
  doctors: Doctor[];
  specialties: Specialty[];
  searchTerm: string;
  setSearchTerm: (s: string) => void;
  selectedSpecialty: SpecialtyType | null;
  setSelectedSpecialty: (s: SpecialtyType | null) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error("useData must be used within DataProvider");
  return context;
};

const PageWrapper: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -10 }}
    transition={{ duration: 0.3 }}
  >
    {children}
  </motion.div>
);

const App: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // 1. Initial Data State (Load from constants or API)
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  
  // 2. Filter States with LocalStorage recovery
  const [searchTerm, setSearchTerm] = useState(() => 
    localStorage.getItem('dorak_search') || ''
  );
  const [selectedSpecialty, setSelectedSpecialty] = useState<SpecialtyType | null>(() => {
    const saved = localStorage.getItem('dorak_specialty');
    return saved ? saved as SpecialtyType : null;
  });
  
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [activeDoctor, setActiveDoctor] = useState<Doctor | null>(null);

  // 3. Persistent Load Logic
  useEffect(() => {
    const cachedDocs = localStorage.getItem('dorak_docs_cache');
    const cachedSpecs = localStorage.getItem('dorak_specs_cache');

    if (cachedDocs && cachedSpecs) {
      setDoctors(JSON.parse(cachedDocs));
      setSpecialties(JSON.parse(cachedSpecs));
    } else {
      setDoctors(DOCTORS);
      setSpecialties(SPECIALTIES);
      localStorage.setItem('dorak_docs_cache', JSON.stringify(DOCTORS));
      localStorage.setItem('dorak_specs_cache', JSON.stringify(SPECIALTIES));
    }
  }, []);

  // 4. Persistence Sync
  useEffect(() => {
    localStorage.setItem('dorak_search', searchTerm);
  }, [searchTerm]);

  useEffect(() => {
    if (selectedSpecialty) {
      localStorage.setItem('dorak_specialty', selectedSpecialty);
    } else {
      localStorage.removeItem('dorak_specialty');
    }
  }, [selectedSpecialty]);

  useEffect(() => {
    const specParam = searchParams.get('specialty');
    if (specParam) {
      const found = Object.values(SpecialtyType).find(
        v => v.toLowerCase() === specParam.toLowerCase()
      );
      if (found) setSelectedSpecialty(found as SpecialtyType);
    }
  }, [searchParams]);

  const [bookingFlow, setBookingFlow] = useState<{
    step: 1 | 2 | 3;
    doctor: Doctor | null;
    branch: Branch | null;
    booking: Booking | null;
  }>({ step: 1, doctor: null, branch: null, booking: null });

  const handleStartBooking = (doctor: Doctor) => {
    setActiveDoctor(doctor);
    setIsBookingModalOpen(true);
  };

  const saveToHistory = (booking: Booking, doctor: Doctor, branch: Branch) => {
    const savedBookings = JSON.parse(localStorage.getItem('userBookings') || '[]');
    const bookingToSave = {
      id: booking.id,
      doctorName: doctor.name,
      doctorTitle: doctor.title,
      doctorImage: doctor.image,
      specialty: doctor.specialty,
      branchName: branch.name,
      branchAddress: branch.address,
      turnNumber: booking.turnNumber,
      // Fix: booking.bookedAt is already a string according to the Booking interface (line 127)
      bookedAt: booking.bookedAt,
      lat: branch.lat,
      lng: branch.lng
    };
    localStorage.setItem('userBookings', JSON.stringify([bookingToSave, ...savedBookings]));
  };

  // Added missing properties to the Booking object to satisfy the interface requirements
  const handleConfirmBooking = (name: string, phone: string, branch: Branch) => {
    const newBooking: Booking = {
      id: Math.random().toString(36).substr(2, 9),
      patientName: name,
      patientPhone: phone,
      doctorId: activeDoctor!.id,
      doctorName: activeDoctor!.name,
      doctorSpecialty: activeDoctor!.specialty,
      doctorImage: activeDoctor!.image,
      branchId: branch.id,
      branchName: branch.name,
      turnNumber: 15,
      bookedAt: new Date().toISOString(),
      status: 'confirmed',
      consultationFee: activeDoctor!.consultationFee,
      serviceFee: activeDoctor!.serviceFee
    };
    
    saveToHistory(newBooking, activeDoctor!, branch);

    setBookingFlow({ step: 3, doctor: activeDoctor, branch, booking: newBooking });
    setIsBookingModalOpen(false);
    navigate('/booking');
  };

  const resetBookingFlow = () => {
    setBookingFlow({ step: 1, doctor: null, branch: null, booking: null });
    navigate('/', { replace: true });
  };

  return (
    <DataContext.Provider value={{ 
      doctors, 
      specialties, 
      searchTerm, 
      setSearchTerm, 
      selectedSpecialty, 
      setSelectedSpecialty 
    }}>
      <Layout>
        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={
              <PageWrapper>
                <Home 
                  searchTerm={searchTerm} 
                  setSearchTerm={setSearchTerm}
                  onBookNow={handleStartBooking}
                />
              </PageWrapper>
            } />
            
            <Route path="/doctors" element={
              <PageWrapper>
                <DoctorsPage 
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  selectedSpecialty={selectedSpecialty}
                  setSelectedSpecialty={setSelectedSpecialty}
                  onBookNow={handleStartBooking}
                />
              </PageWrapper>
            } />

            <Route path="/booking" element={
              <PageWrapper>
                <BookingPage 
                  flow={bookingFlow}
                  setFlow={setBookingFlow}
                  onReset={resetBookingFlow}
                  onSaveToHistory={saveToHistory}
                />
              </PageWrapper>
            } />

            <Route path="/about" element={
              <PageWrapper>
                <AboutPage />
              </PageWrapper>
            } />

            <Route path="/profile" element={
              <PageWrapper>
                <ProfilePage />
              </PageWrapper>
            } />
          </Routes>
        </AnimatePresence>

        {activeDoctor && (
          <BookingModal 
            isOpen={isBookingModalOpen}
            onClose={() => setIsBookingModalOpen(false)}
            doctor={activeDoctor}
            onConfirm={handleConfirmBooking}
          />
        )}
      </Layout>
    </DataContext.Provider>
  );
};

export default App;
