
import React, { useMemo } from 'react';
import { Search, UserSearch, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { SpecialtyType, Doctor } from '../types';
import { DOCTORS, SPECIALTIES, SPECIALTY_LABELS, getIcon } from '../constants';
import DoctorCard from '../components/DoctorCard';

const normalizeText = (text: string): string => {
  return text
    .trim()
    .toLowerCase()
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/[ىي]/g, 'ي')
    .replace(/[\u064B-\u065F]/g, '');
};

interface DoctorsPageProps {
  searchTerm: string;
  setSearchTerm: (val: string) => void;
  selectedSpecialty: SpecialtyType | null;
  setSelectedSpecialty: (val: SpecialtyType | null) => void;
  onBookNow: (doctor: Doctor) => void;
}

const DoctorsPage: React.FC<DoctorsPageProps> = ({ 
  searchTerm, 
  setSearchTerm, 
  selectedSpecialty, 
  setSelectedSpecialty,
  onBookNow
}) => {
  const filteredDoctors = useMemo(() => {
    const normalizedTerm = normalizeText(searchTerm);
    
    return DOCTORS.filter(doc => {
      const matchesSpec = selectedSpecialty ? doc.specialty === selectedSpecialty : true;
      if (!normalizedTerm) return matchesSpec;
      
      const branchNames = doc.branches.map(b => b.name).join(' ');
      const specialtyLabel = SPECIALTY_LABELS[doc.specialty] || '';
      const searchableContent = normalizeText(`${doc.name} ${doc.title} ${specialtyLabel} ${doc.location} ${branchNames}`);
      
      return matchesSpec && searchableContent.includes(normalizedTerm);
    });
  }, [selectedSpecialty, searchTerm]);

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 md:py-16">
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row-reverse items-center justify-between mb-10 md:mb-16 gap-8">
        <h1 className="text-3xl md:text-5xl font-black tracking-tighter text-slate-900 dark:text-white">دليل الأطباء</h1>
        <div className="w-full max-w-xl bg-white dark:bg-slate-900 p-4 rounded-3xl shadow-xl flex flex-row-reverse items-center gap-4 border border-slate-100 dark:border-slate-800 focus-within:ring-4 focus-within:ring-blue-100 dark:focus-within:ring-blue-900/30 transition-all">
           <input 
            type="text" 
            value={searchTerm} 
            onChange={(e) => setSearchTerm(e.target.value)} 
            placeholder="ابحث بالاسم، التخصص، أو اسم العيادة..." 
            className="flex-1 text-right bg-transparent outline-none font-bold text-slate-700 dark:text-white placeholder:text-slate-300"
           />
           <Search className="text-slate-300" />
        </div>
      </div>

      {/* Specialty Filter - Horizontal on Mobile, Sidebar on Desktop */}
      <div className="block md:hidden mb-8 overflow-x-auto whitespace-nowrap scrollbar-hide -mx-6 px-6">
        <div className="flex gap-2">
          <button 
            onClick={() => setSelectedSpecialty(null)}
            className={`px-6 py-3 rounded-2xl font-black text-sm transition-all border-2 ${!selectedSpecialty ? 'bg-[#1e40af] border-[#1e40af] text-white' : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 text-slate-400'}`}
          >
            الكل
          </button>
          {SPECIALTIES.map(spec => (
            <button 
              key={spec.type}
              onClick={() => setSelectedSpecialty(spec.type)}
              className={`px-6 py-3 rounded-2xl font-black text-sm transition-all border-2 flex items-center gap-2 ${selectedSpecialty === spec.type ? 'bg-[#1e40af] border-[#1e40af] text-white shadow-lg' : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 text-slate-400'}`}
            >
              <span>{SPECIALTY_LABELS[spec.type]}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
        {/* Desktop Sidebar Filters */}
        <div className="hidden lg:block lg:col-span-1 space-y-8 sticky top-32 h-fit">
           <div className="bg-white dark:bg-slate-900 p-8 rounded-[40px] shadow-sm border border-slate-50 dark:border-slate-800">
              <div className="flex items-center justify-between flex-row-reverse mb-8">
                <h3 className="text-xl font-black text-slate-900 dark:text-white">التخصص</h3>
                {selectedSpecialty && (
                  <button onClick={() => setSelectedSpecialty(null)} className="text-[#1e40af] font-bold text-xs hover:underline">
                    مسح الكل
                  </button>
                )}
              </div>
              <div className="space-y-2">
                 {SPECIALTIES.map(spec => (
                   <button 
                    key={spec.type}
                    onClick={() => setSelectedSpecialty(spec.type === selectedSpecialty ? null : spec.type)}
                    className={`w-full flex flex-row-reverse items-center justify-between p-4 rounded-2xl transition-all duration-300 border-2 ${selectedSpecialty === spec.type ? 'bg-[#1e40af] border-[#1e40af] text-white shadow-lg scale-[1.02]' : 'border-transparent hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-500'}`}
                   >
                     <span className="font-bold">{SPECIALTY_LABELS[spec.type]}</span>
                     {getIcon(spec.icon, 18)}
                   </button>
                 ))}
              </div>
           </div>
        </div>

        {/* Results Area */}
        <div className="lg:col-span-3 space-y-8">
          <AnimatePresence mode="popLayout">
            {filteredDoctors.length > 0 ? (
              filteredDoctors.map((doc, idx) => (
                <motion.div
                  key={doc.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3, delay: idx * 0.05 }}
                >
                  <DoctorCard 
                    doctor={doc} 
                    onViewProfile={() => {}} 
                    onBookNow={onBookNow} 
                  />
                </motion.div>
              ))
            ) : (
              <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="py-24 text-center bg-white dark:bg-slate-900/40 rounded-[56px] border-4 border-dashed border-slate-100 dark:border-slate-800 flex flex-col items-center">
                <div className="w-24 h-24 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mb-8">
                  <UserSearch size={48} className="text-slate-200" />
                </div>
                <h3 className="text-2xl md:text-3xl font-[1000] text-slate-400 mb-4 px-4 tracking-tighter">عذراً، لا يوجد أطباء في هذا التخصص حالياً</h3>
                <p className="text-slate-300 font-bold mb-10 max-w-md">جرب البحث بكلمات مختلفة أو تصفح كافة التخصصات المتاحة</p>
                <button 
                  onClick={() => { setSearchTerm(''); setSelectedSpecialty(null); }} 
                  className="bg-[#1e40af] text-white font-black px-10 py-5 rounded-3xl shadow-xl hover:bg-blue-800 transition-all flex items-center gap-3"
                >
                  <RefreshCw size={20} />
                  <span>إعادة ضبط البحث</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default DoctorsPage;
