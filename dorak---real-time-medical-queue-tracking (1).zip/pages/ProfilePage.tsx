
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  MapPin, 
  User, 
  LogOut,
  ClipboardList,
  Banknote,
  CheckCircle2,
  Stethoscope,
  ChevronLeft,
  ArrowRight,
  RefreshCw,
  Search
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { SPECIALTY_LABELS, DOCTORS } from '../constants';
import { Booking } from '../types';

const ProfilePage: React.FC = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);

  useEffect(() => {
    const savedUser = localStorage.getItem('dorak_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    } else {
      navigate('/');
    }

    // جلب التاريخ الموحد من LocalStorage بناءً على رقم الهاتف
    const savedBookings = JSON.parse(localStorage.getItem('userBookings') || '[]');
    setBookings(savedBookings);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('dorak_user');
    window.location.href = '/';
  };

  const handleBookAgain = (doctorId: string) => {
    const doctor = DOCTORS.find(d => d.id === doctorId);
    if (doctor) {
      // توجيه لصفحة الأطباء مع تفعيل الطبيب المختار
      navigate(`/doctors?search=${encodeURIComponent(doctor.name)}`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-24" dir="rtl">
      {/* Patient Identity Header */}
      <section className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 pt-16 pb-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row-reverse items-center justify-between gap-8">
          <div className="flex flex-col md:flex-row-reverse items-center gap-6">
            <div className="w-24 h-24 md:w-32 md:h-32 bg-[#1e40af] rounded-[35px] flex items-center justify-center text-white shadow-2xl relative">
              <User size={48} />
              <div className="absolute -bottom-2 -right-2 bg-emerald-500 w-8 h-8 rounded-full border-4 border-white dark:border-slate-900 flex items-center justify-center">
                <CheckCircle2 size={14} className="text-white" />
              </div>
            </div>
            <div className="text-center md:text-right">
              <h1 className="text-3xl md:text-5xl font-[1000] text-slate-900 dark:text-white tracking-tighter mb-1">
                {user?.name}
              </h1>
              <div className="flex items-center justify-center md:justify-start gap-3 text-slate-400 font-bold">
                <span className="bg-blue-50 dark:bg-blue-900/20 text-[#1e40af] px-3 py-1 rounded-lg text-xs font-black">رقم موحد</span>
                <p className="text-sm md:text-lg">{user?.phone}</p>
              </div>
            </div>
          </div>
          
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 px-8 py-4 rounded-2xl bg-white dark:bg-slate-800 text-slate-500 font-black border border-slate-100 dark:border-slate-700 hover:text-red-500 transition-all shadow-sm"
          >
            <span>خروج</span>
            <LogOut size={18} />
          </button>
        </div>
      </section>

      {/* Medical History Engine */}
      <div className="max-w-6xl mx-auto px-6 mt-16">
        <div className="flex items-center justify-between mb-10 flex-row-reverse">
           <div className="flex items-center gap-3 flex-row-reverse">
              <ClipboardList className="text-[#1e40af]" size={32} />
              <h2 className="text-3xl font-[1000] text-slate-900 dark:text-white tracking-tighter">سجل الأطباء والتعاملات</h2>
           </div>
        </div>

        {bookings.length > 0 ? (
          <div className="grid grid-cols-1 gap-6">
            {bookings.map((booking, idx) => (
              <motion.div
                key={booking.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-white dark:bg-slate-900 rounded-[40px] p-8 border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl hover:border-blue-200 dark:hover:border-blue-900 transition-all flex flex-col lg:flex-row-reverse items-center justify-between gap-8 group"
              >
                <div className="flex flex-col md:flex-row-reverse items-center gap-6 flex-1 w-full text-center md:text-right">
                   <div className="w-20 h-20 md:w-24 md:h-24 rounded-[30px] overflow-hidden border-4 border-white dark:border-slate-800 shadow-lg shrink-0 group-hover:scale-105 transition-transform">
                      <img src={booking.doctorImage} alt={booking.doctorName} className="w-full h-full object-cover" />
                   </div>
                   <div className="flex-1">
                      <div className="flex flex-col md:flex-row-reverse items-center gap-3 mb-2">
                         <h3 className="text-2xl font-black text-slate-900 dark:text-white">{booking.doctorName}</h3>
                         <span className="px-3 py-1 bg-blue-50 dark:bg-blue-900/30 text-[#1e40af] rounded-full text-[10px] font-black">
                            {SPECIALTY_LABELS[booking.doctorSpecialty as any] || booking.doctorSpecialty}
                         </span>
                      </div>
                      <div className="flex flex-wrap items-center justify-center md:justify-start gap-x-6 gap-y-2 text-slate-400 font-bold text-sm">
                         <div className="flex items-center gap-2 flex-row-reverse">
                            <Calendar size={16} className="text-slate-300" />
                            <span>{new Date(booking.bookedAt).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                         </div>
                         <div className="flex items-center gap-2 flex-row-reverse">
                            <MapPin size={16} className="text-slate-300" />
                            <span>{booking.branchName}</span>
                         </div>
                      </div>
                   </div>
                </div>

                <div className="flex flex-row lg:flex-col items-center gap-6 w-full lg:w-auto pt-6 lg:pt-0 border-t lg:border-t-0 lg:border-r border-slate-100 dark:border-slate-800 lg:pr-8">
                   <div className="flex-1 lg:text-center text-right">
                      <p className="text-[10px] font-black text-slate-400 uppercase mb-1 tracking-widest">قيمة الكشف</p>
                      <div className="flex items-center lg:justify-center gap-1.5 font-black">
                         <span className="text-2xl text-slate-900 dark:text-white">{booking.consultationFee}</span>
                         <span className="text-sm text-slate-400">ج.م</span>
                      </div>
                   </div>
                   
                   <button 
                    onClick={() => handleBookAgain(booking.doctorId)}
                    className="flex-1 lg:w-full bg-[#1e40af] text-white font-black px-8 py-4 rounded-2xl text-sm hover:bg-blue-800 shadow-lg shadow-blue-100 dark:shadow-none transition-all flex items-center justify-center gap-2"
                   >
                     <RefreshCw size={16} />
                     <span>احجز مرة أخرى</span>
                   </button>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="py-32 bg-white dark:bg-slate-900 rounded-[60px] border-4 border-dashed border-slate-100 dark:border-slate-800 flex flex-col items-center text-center px-10">
            <Search size={64} className="text-slate-200 mb-8" />
            <h3 className="text-3xl font-[1000] text-slate-900 dark:text-white mb-4 tracking-tighter">سجلاتك فارغة حالياً</h3>
            <p className="text-slate-400 font-bold text-lg mb-12 max-w-sm">ابدأ حجزك الأول مع نخبة من أفضل الأطباء في مصر عبر منصة دورك.</p>
            <button 
              onClick={() => navigate('/doctors')}
              className="bg-[#1e40af] text-white font-black px-12 py-5 rounded-[25px] shadow-2xl hover:bg-blue-800 transition-all flex items-center gap-3"
            >
              <span>استكشف الأطباء الآن</span>
              <ChevronLeft size={20} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;
