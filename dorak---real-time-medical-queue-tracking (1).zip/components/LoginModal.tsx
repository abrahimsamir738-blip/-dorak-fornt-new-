import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, User, Phone, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (name: string) => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (name.trim().length < 3) {
      setError('يرجى إدخال الاسم بالكامل (3 أحرف على الأقل)');
      return;
    }

    if (!/^01[0125][0-9]{8}$/.test(phone)) {
      setError('يرجى إدخال رقم موبايل مصري صحيح');
      return;
    }

    // Save unified account to LocalStorage
    const userData = { name, phone, id: `u_${phone}` };
    localStorage.setItem('dorak_user', JSON.stringify(userData));
    
    setIsSuccess(true);
    setTimeout(() => {
      onLoginSuccess(name);
      onClose();
      setIsSuccess(false);
      setName('');
      setPhone('');
    }, 1500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
          />

          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-[40px] p-8 md:p-12 shadow-2xl border border-white/20 dark:border-slate-800/50 overflow-hidden"
            dir="rtl"
          >
            <AnimatePresence>
              {isSuccess && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute inset-0 z-50 bg-[#1e40af] flex flex-col items-center justify-center text-white p-6 text-center"
                >
                  <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }}>
                    <CheckCircle2 size={72} className="mb-6" />
                  </motion.div>
                  <h3 className="text-3xl font-black mb-2">تم الدخول آمن</h3>
                  <p className="text-blue-100 font-bold">مرحباً بك في منصة دورك الموحدة</p>
                </motion.div>
              )}
            </AnimatePresence>

            <button
              onClick={onClose}
              className="absolute top-6 left-6 w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 hover:text-red-500 transition-colors z-10"
            >
              <X size={20} />
            </button>

            <div className="text-center mb-10">
              <div className="w-20 h-20 bg-[#1e40af] rounded-3xl flex items-center justify-center text-white shadow-xl mx-auto mb-6">
                <ShieldCheck size={40} />
              </div>
              <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-2 tracking-tighter">دخول المنصة</h2>
              <p className="text-slate-400 text-sm font-bold">سجل دخولك برقم الهاتف لمتابعة حجوزاتك</p>
            </div>

            {/* Social Icons removed as per request for simplified entry point */}
            <form onSubmit={handleSubmit} className="space-y-6 flex flex-col items-center w-full">
              <div className="space-y-2 w-full">
                <label className="text-xs font-black text-slate-400 mr-2 uppercase tracking-widest block text-right">الاسم الكامل</label>
                <div className="relative">
                  <User className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                  <input 
                    type="text" 
                    required 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                    placeholder="أدخل اسمك كما في البطاقة" 
                    className="w-full bg-slate-50 dark:bg-slate-800/40 border-2 border-transparent focus:border-[#1e40af] rounded-2xl py-4 pr-12 pl-4 text-right font-bold outline-none transition-all" 
                  />
                </div>
              </div>
              
              <div className="space-y-2 w-full">
                <label className="text-xs font-black text-slate-400 mr-2 uppercase tracking-widest block text-right">رقم الموبايل</label>
                <div className="relative">
                  <Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                  <input 
                    type="tel" 
                    required 
                    value={phone} 
                    onChange={(e) => setPhone(e.target.value)} 
                    placeholder="01XXXXXXXXX" 
                    className="w-full bg-slate-50 dark:bg-slate-800/40 border-2 border-transparent focus:border-[#1e40af] rounded-2xl py-4 pr-12 pl-4 text-right font-bold outline-none transition-all" 
                  />
                </div>
              </div>

              {error && (
                <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-red-500 text-xs font-bold text-center">
                  {error}
                </motion.p>
              )}

              <button 
                type="submit" 
                className="w-full bg-[#1e40af] text-white font-black text-xl py-5 rounded-2xl shadow-xl shadow-blue-200 dark:shadow-none hover:bg-blue-800 transition-all active:scale-95 mt-4"
              >
                دخول المنصة
              </button>
              
              <p className="text-center text-[10px] text-slate-400 font-bold leading-relaxed px-4">
                بمجرد الدخول، أنت توافق على شروط الاستخدام الطبية لمنصة دورك.
              </p>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default LoginModal;