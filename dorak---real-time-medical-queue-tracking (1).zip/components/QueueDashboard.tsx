
import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  MapPin, 
  ShieldCheck, 
  Activity, 
  Navigation,
  BellRing,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

interface QueueDashboardProps {
  userTurn: number;
  clinicName: string;
  doctorName?: string;
  doctorLocation?: string;
  lat?: number;
  lng?: number;
  onBack?: () => void;
}

const QueueDashboard: React.FC<QueueDashboardProps> = ({ 
  userTurn, 
  clinicName, 
  doctorName, 
  doctorLocation, 
  lat, 
  lng,
  onBack
}) => {
  const [currentTurn, setCurrentTurn] = useState(1);
  const [waitTime, setWaitTime] = useState(0);
  const [isAlertActive, setIsAlertActive] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    setCurrentTurn(Math.max(1, userTurn - 2));
    const interval = setInterval(() => {
      setCurrentTurn(prev => {
        if (prev < userTurn) return prev + 1;
        return prev;
      });
    }, 45000);
    return () => clearInterval(interval);
  }, [userTurn]);

  useEffect(() => {
    const diff = userTurn - currentTurn;
    setWaitTime(diff > 0 ? diff * 10 : 0);
    
    if (isAlertActive && diff === 2) {
      if ("Notification" in window) {
         new Notification("تنبيه دورك!", {
          body: `اقترب دورك في ${clinicName}. هناك مريضان فقط أمامك.`,
          icon: "/favicon.ico"
        });
      }
    }
  }, [currentTurn, userTurn, isAlertActive, clinicName]);

  const handleToggleAlert = async () => {
    if (!isAlertActive) {
      if ("Notification" in window) {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
          setIsAlertActive(true);
        } else {
          alert("يرجى تفعيل التنبيهات من إعدادات المتصفح");
        }
      }
    } else {
      setIsAlertActive(false);
    }
  };

  const handleOpenMaps = () => {
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    if (isMobile) {
      window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(clinicName + ' ' + (doctorLocation || ''))}`, '_blank');
    } else {
      if (lat && lng) {
        window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
      } else {
        window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(clinicName)}`, '_blank');
      }
    }
  };

  const patientsAhead = Math.max(0, userTurn - currentTurn);

  const handleBackNavigation = () => {
    if (onBack) {
      onBack();
    } else {
      navigate('/', { replace: true });
    }
  };

  return (
    <div className="flex flex-col items-center gap-8 md:gap-16 w-full max-w-6xl mx-auto py-10 md:py-20 px-4">
      {/* Main Tracker Card */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full bg-slate-900 dark:bg-slate-900/60 backdrop-blur-3xl rounded-[40px] md:rounded-[100px] p-8 md:p-20 text-white shadow-2xl relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-full h-full pointer-events-none opacity-20">
           <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_20%_20%,#3b82f6,transparent)]" />
        </div>

        <div className="flex justify-center mb-8 md:mb-16">
          <div className="bg-emerald-500/10 border border-emerald-500/20 px-6 py-2 md:px-8 md:py-3 rounded-full flex items-center gap-3">
            <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></div>
            <span className="text-emerald-500 text-sm md:text-lg font-black tracking-widest uppercase">تتبع حي مباشر</span>
          </div>
        </div>

        <h2 className="text-3xl md:text-7xl font-[950] text-center mb-12 md:mb-24 tracking-tighter leading-tight">{clinicName}</h2>

        {/* Numbers Section */}
        <div className="flex flex-col md:flex-row-reverse justify-center items-center gap-10 md:gap-24 mb-12 md:mb-24">
          <div className="text-center">
            <p className="text-slate-400 text-lg md:text-2xl font-black mb-4">يتم خدمته الآن</p>
            <div className="text-[100px] md:text-[260px] font-[1000] leading-none bg-gradient-to-b from-emerald-300 via-emerald-500 to-emerald-700 bg-clip-text text-transparent tracking-tighter">
              {currentTurn}
            </div>
          </div>

          <div className="hidden md:block w-[1px] h-64 bg-white/10"></div>

          <div className="text-center w-full md:w-auto">
             <div className="bg-white/5 rounded-[40px] md:rounded-[80px] p-8 md:p-16 border border-white/5 backdrop-blur-2xl shadow-inner">
               <p className="text-slate-400 text-lg md:text-2xl font-black mb-4">رقم دورك أنت</p>
               <div className="text-[80px] md:text-[200px] font-[1000] leading-none tracking-tighter">
                {userTurn}
               </div>
               <p className="text-blue-500 text-lg md:text-xl font-black mt-6 tracking-widest uppercase">حجز مؤكد</p>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 px-4 md:px-10">
          <div className="flex flex-row-reverse items-center justify-center md:justify-start gap-6 md:gap-8">
            <div className="w-16 h-16 md:w-20 md:h-20 bg-white/5 rounded-2xl md:rounded-[32px] flex items-center justify-center text-blue-400 border border-white/5">
              <Clock size={32} className="md:w-10 md:h-10" />
            </div>
            <div className="text-right">
              <p className="text-slate-500 text-xs md:text-sm font-black uppercase mb-1 tracking-widest">الانتظار المتوقع</p>
              <p className="text-2xl md:text-4xl font-[950]">~ {waitTime} دقيقة</p>
            </div>
          </div>

          <div className="flex flex-row-reverse items-center justify-center md:justify-start gap-6 md:gap-8">
            <div className="w-16 h-16 md:w-20 md:h-20 bg-white/5 rounded-2xl md:rounded-[32px] flex items-center justify-center text-emerald-400 border border-white/5">
              <Activity size={32} className="md:w-10 md:h-10" />
            </div>
            <div className="text-right">
              <p className="text-slate-500 text-xs md:text-sm font-black uppercase mb-1 tracking-widest">الحالات المتبقية</p>
              <p className="text-2xl md:text-4xl font-[950]">{patientsAhead} حالات</p>
            </div>
          </div>

          <div className="flex flex-row-reverse items-center justify-center md:justify-start gap-6 md:gap-8">
            <div className="w-16 h-16 md:w-20 md:h-20 bg-white/5 rounded-2xl md:rounded-[32px] flex items-center justify-center text-blue-400 border border-white/5">
              <ShieldCheck size={32} className="md:w-10 md:h-10" />
            </div>
            <div className="text-right">
              <p className="text-slate-500 text-xs md:text-sm font-black uppercase mb-1 tracking-widest">الجاهزية</p>
              <p className="text-2xl md:text-4xl font-[950] text-emerald-500">جاهز</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Interactive Footer Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 w-full">
        <div className={`rounded-[40px] md:rounded-[80px] p-10 md:p-16 text-white flex flex-col items-center text-center shadow-2xl relative overflow-hidden group transition-all duration-500 ${isAlertActive ? 'bg-emerald-600' : 'bg-blue-600'}`}>
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-32 -mt-32 transition-transform duration-700 group-hover:scale-150" />
          <h3 className="text-3xl md:text-5xl font-[950] mb-4 md:mb-6 tracking-tighter">تنبيه ذكي</h3>
          <p className="text-blue-50 text-lg md:text-2xl font-bold mb-8 md:mb-12 max-w-sm leading-relaxed">
            {isAlertActive ? "نظام التنبيه مفعل! سنرسل لك إشعاراً عندما يقترب دورك." : "سنقوم بتنبيهك عبر المتصفح عندما يقترب دورك بـ مريضين."}
          </p>
          <button 
            onClick={handleToggleAlert}
            className={`font-[950] text-xl md:text-2xl py-5 md:py-6 px-10 md:px-16 rounded-[24px] md:rounded-[32px] shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-4 ${isAlertActive ? 'bg-white text-emerald-600' : 'bg-white text-blue-600'}`}
          >
            {isAlertActive ? "إلغاء التنبيه" : "تفعيل التنبيه"}
            <div className={isAlertActive ? "animate-bounce" : ""}>
              <BellRing size={28} />
            </div>
          </button>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-[40px] md:rounded-[80px] p-10 md:p-16 flex flex-col items-center text-center shadow-xl border border-slate-100 dark:border-slate-800 relative group">
          <div className="flex flex-col md:flex-row-reverse items-center gap-6 md:gap-8 mb-10 md:mb-12">
            <div className="w-20 h-20 md:w-24 md:h-24 bg-blue-50 dark:bg-blue-900/20 text-blue-600 rounded-[24px] md:rounded-[32px] flex items-center justify-center">
              <MapPin size={40} className="md:w-12 md:h-12" />
            </div>
            <div className="text-center md:text-right">
              <h4 className="text-2xl md:text-4xl font-[950] text-slate-900 dark:text-white tracking-tighter mb-1 md:mb-2">{doctorName}</h4>
              <p className="text-lg md:text-2xl text-slate-400 font-bold">{doctorLocation}</p>
            </div>
          </div>
          
          <button 
            onClick={handleOpenMaps}
            className="w-full bg-[#0b1221] dark:bg-blue-600 text-white font-[950] text-xl md:text-2xl py-8 md:py-10 rounded-[30px] md:rounded-[40px] flex items-center justify-center gap-6 hover:opacity-90 transition-all hover:scale-[1.02]"
          >
            <Navigation size={32} className="text-emerald-400" />
            فتح المسار في الخرائط
          </button>
        </div>
      </div>

      <button 
        className="mt-8 text-slate-400 dark:text-slate-600 font-black text-xl md:text-2xl hover:text-red-500 transition-colors flex items-center gap-4 group"
        onClick={handleBackNavigation}
      >
        <span>إلغاء الحجز والعودة</span>
        <ArrowRight size={24} className="group-hover:translate-x-2 transition-transform" />
      </button>
    </div>
  );
};

export default QueueDashboard;
