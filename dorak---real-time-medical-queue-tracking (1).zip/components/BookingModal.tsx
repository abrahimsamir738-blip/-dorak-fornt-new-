import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Clock, MapPin, ShieldCheck, Phone, User } from 'lucide-react';
import { Doctor, Branch } from '../types';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  doctor: Doctor;
  onConfirm: (name: string, phone: string, branch: Branch) => void;
}

const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, doctor, onConfirm }) => {
  const [name, setName] = React.useState('');
  const [phone, setPhone] = React.useState('');
  const [selectedBranch, setSelectedBranch] = React.useState<Branch>(doctor.branches[0]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && phone && selectedBranch) {
      onConfirm(name, phone, selectedBranch);
    }
  };

  const nextTurn = (doctor.currentQueueCount || 0) + 1;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[300] flex items-end md:items-center justify-center">
          {/* Backdrop */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />

          {/* Modal Content */}
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="relative w-full md:max-w-2xl bg-white dark:bg-slate-900 rounded-t-[40px] md:rounded-[40px] shadow-2xl p-6 md:p-12 overflow-y-auto max-h-[90vh] text-right"
            dir="rtl"
          >
            <button 
              onClick={onClose}
              className="absolute top-6 left-6 w-10 h-10 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 hover:text-red-500 transition-colors"
            >
              <X size={20} />
            </button>

            <div className="flex flex-col md:flex-row-reverse items-center md:items-start gap-6 mb-10 border-b border-slate-100 dark:border-slate-800 pb-8">
              <div className="w-24 h-24 rounded-3xl overflow-hidden border-4 border-blue-50 shrink-0">
                <img src={doctor.image} alt={doctor.name} className="w-full h-full object-cover" />
              </div>
              <div className="text-center md:text-right">
                <h3 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white mb-2">{doctor.name}</h3>
                <p className="text-[#1e40af] font-bold mb-4">{doctor.title}</p>
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-slate-400 text-sm font-bold">
                   <div className="flex items-center gap-2">
                      <Clock size={16} className="text-[#1e40af]" />
                      <span>{selectedBranch.workingHours}</span>
                   </div>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <label className="text-xs font-black text-slate-400 mr-2 uppercase tracking-widest block">اختر الفرع</label>
                <div className="grid grid-cols-1 gap-3">
                  {doctor.branches.map(branch => (
                    <button
                      key={branch.id}
                      type="button"
                      onClick={() => setSelectedBranch(branch)}
                      className={`p-4 rounded-2xl border-2 transition-all flex items-center justify-between ${selectedBranch.id === branch.id ? 'border-[#1e40af] bg-blue-50/10' : 'border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50'}`}
                    >
                      <div className="text-right">
                        <p className="font-black text-slate-800 dark:text-white">{branch.name}</p>
                        <p className="text-xs text-slate-400 font-bold">{branch.address}</p>
                      </div>
                      <MapPin size={18} className={selectedBranch.id === branch.id ? 'text-[#1e40af]' : 'text-slate-300'} />
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 mr-2 uppercase tracking-widest">اسم المريض</label>
                  <div className="relative">
                    <User className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input 
                      type="text" 
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="الاسم الثلاثي"
                      className="w-full bg-slate-50 dark:bg-slate-800/50 border-2 border-transparent focus:border-[#1e40af] rounded-2xl py-4 pr-12 pl-4 text-right font-bold outline-none"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 mr-2 uppercase tracking-widest">رقم الهاتف</label>
                  <div className="relative">
                    <Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                    <input 
                      type="tel" 
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="01XXXXXXXXX"
                      className="w-full bg-slate-50 dark:bg-slate-800/50 border-2 border-transparent focus:border-[#1e40af] rounded-2xl py-4 pr-12 pl-4 text-right font-bold outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Updated Info Box */}
              <div className="bg-blue-50 dark:bg-blue-900/20 p-5 rounded-2xl flex items-center gap-4 border border-blue-100 dark:border-blue-800">
                <ShieldCheck className="text-[#1e40af] shrink-0" size={24} />
                <p className="text-xs font-bold text-slate-700 dark:text-blue-400 leading-relaxed">
                  تنبيه: يتم دفع إجمالي المبلغ (سعر الكشف + 15 ج.م رسوم الخدمة) نقداً داخل العيادة. لا يوجد دفع أونلاين.
                </p>
              </div>

              {/* Next Turn Logic Display */}
              <div className="text-center pt-2 bg-slate-50 dark:bg-slate-800/50 py-4 rounded-2xl border-2 border-dashed border-blue-100 dark:border-blue-900/50">
                <p className="text-lg font-black text-slate-900 dark:text-white">
                  دورك المتوقع هو رقم: <span className="text-[#1e40af] text-3xl">{nextTurn}</span>
                </p>
              </div>

              <button 
                type="submit"
                className="w-full bg-[#1e40af] text-white font-black text-xl py-5 rounded-2xl shadow-xl hover:bg-blue-800 transition-all flex items-center justify-center gap-3 active:scale-95"
              >
                <span>تأكيد الحجز</span>
                <Clock size={20} />
              </button>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default BookingModal;